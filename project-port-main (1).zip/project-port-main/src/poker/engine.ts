import { recordAction, recordShowdownTells } from '@/poker/opponent-model';
import { createDeck, type Card } from '@/poker/cards';
import { describeScore, evaluateBest, scoreCategory } from '@/poker/evaluate';
import type { Action, Award, HandState, LegalInfo, Seat, TableConfig, TableState } from '@/poker/types';

/** Every table seats at most 8 players (real players plus AI). */
export const SEAT_COUNT = 8;

export function emptyTable(config?: TableConfig): TableState {
  return {
    seats: Array<Seat | null>(SEAT_COUNT).fill(null),
    dealer: 0,
    hand: null,
    handCount: 0,
    config: config ?? { smallBlind: 10, bigBlind: 20, minBuyIn: 500, maxBuyIn: 20000 },
  };
}

function cloneTable(table: TableState): TableState {
  return {
    ...table,
    seats: table.seats.map((seat) => (seat ? { ...seat, hole: [...seat.hole] } : null)),
    hand: table.hand
      ? {
          ...table.hand,
          board: [...table.hand.board],
          deck: [...table.hand.deck],
          winners: [...table.hand.winners],
        }
      : null,
  };
}

export function canPlay(seat: Seat): boolean {
  return !seat.sittingOut && seat.stack > 0;
}

export function nextSeat(seats: (Seat | null)[], from: number, match: (seat: Seat) => boolean): number | null {
  // Uses the array length so older 9-seat tables finish their current hand safely.
  const count = seats.length;
  for (let step = 1; step <= count; step++) {
    const index = (from + step) % count;
    const seat = seats[index];
    if (seat && match(seat)) return index;
  }
  return null;
}

export function potTotal(table: TableState): number {
  if (!table.hand) return 0;
  return table.hand.pot + table.seats.reduce((sum, seat) => sum + (seat?.bet ?? 0), 0);
}

function commit(seat: Seat, amount: number): void {
  const paid = Math.min(Math.max(amount, 0), seat.stack);
  seat.stack -= paid;
  seat.bet += paid;
  seat.invested += paid;
  if (seat.stack === 0) seat.allIn = true;
}

function draw(deck: Card[]): Card {
  return deck.pop() as Card;
}

function dealStreet(hand: HandState): void {
  const count = hand.street === 'preflop' ? 3 : 1;
  for (let i = 0; i < count; i++) hand.board.push(draw(hand.deck));
  if (hand.street === 'preflop') hand.street = 'flop';
  else if (hand.street === 'flop') hand.street = 'turn';
  else if (hand.street === 'turn') hand.street = 'river';
}

function collectBets(table: TableState): void {
  if (!table.hand) return;
  for (const seat of table.seats) {
    if (!seat) continue;
    table.hand.pot += seat.bet;
    seat.bet = 0;
  }
}

function awardStack(table: TableState, awards: Award[]): void {
  for (const award of awards) {
    const seat = table.seats[award.seat];
    if (seat) seat.stack += award.amount;
  }
}

function finishUncontested(table: TableState, winnerIndex: number): TableState {
  if (!table.hand) return table;
  const amount = potTotal(table);
  collectBets(table);
  const awards: Award[] = [{ seat: winnerIndex, amount, label: 'Everyone else folded' }];
  awardStack(table, awards);
  table.hand.winners = awards;
  table.hand.street = 'complete';
  table.hand.toAct = null;
  table.hand.showdown = false;
  return table;
}

function runOutBoard(hand: HandState): void {
  while (hand.board.length < 5) hand.board.push(draw(hand.deck));
}

const roundMoney = (value: number): number => Math.round(value * 100) / 100;

/** Smallest chip of a table: 1, or a fraction when the blinds are fractions (0.50, 1.50, 2.50...). */
function chipUnit(config: TableConfig): number {
  for (const unit of [1, 0.5, 0.25, 0.1, 0.05, 0.01]) {
    if ([config.smallBlind, config.bigBlind].every((value) => Math.abs(Math.round(value / unit) * unit - value) < 1e-9)) return unit;
  }
  return 0.01;
}

/**
 * Chips nobody matched (the part of the biggest bet that no opponent could call) go straight back to their owner.
 * They are not part of the pot, pay no rake and never count as a win.
 */
function returnUncalledBet(table: TableState): void {
  const hand = table.hand;
  if (!hand) return;
  let top = 0;
  let topSeat = -1;
  let second = 0;
  table.seats.forEach((seat, index) => {
    const value = seat?.invested ?? 0;
    if (value > top) {
      second = top;
      top = value;
      topSeat = index;
    } else if (value > second) {
      second = value;
    }
  });
  const owner = table.seats[topSeat];
  const refund = top - second;
  if (!owner || refund <= 0) return;
  const fromBet = Math.min(refund, owner.bet);
  owner.bet -= fromBet;
  hand.pot -= refund - fromBet;
  owner.invested -= refund;
  owner.stack += refund;
}

function showdown(table: TableState): TableState {
  if (!table.hand) return table;
  const hand = table.hand;
  returnUncalledBet(table);
  const live = table.seats.flatMap((seat, index) => (seat && !seat.folded ? [index] : []));
  const levels = [...new Set(table.seats.map((seat) => seat?.invested ?? 0).filter((v) => v > 0))].sort(
    (a, b) => a - b
  );

  const awards: Award[] = [];
  let previous = 0;
  let rakeTotal = 0;

  for (const level of levels) {
    const amount = table.seats.reduce((sum, seat) => {
      if (!seat) return sum;
      return sum + Math.max(0, Math.min(seat.invested, level) - previous);
    }, 0);
    previous = level;
    if (amount <= 0) continue;

    const contenders = live.filter((index) => (table.seats[index]?.invested ?? 0) >= level);
    const eligible = contenders.length > 0 ? contenders : live;

    const take = Math.floor((amount * hand.rakePercent) / 100);
    rakeTotal += take;
    const distributable = amount - take;

    const scored = eligible.map((index) => {
      const seat = table.seats[index];
      const score = seat ? evaluateBest([...seat.hole, ...hand.board]) : -1;
      return { index, score };
    });
    const best = Math.max(...scored.map((entry) => entry.score));
    const seatCount = table.seats.length;
    // An odd chip goes to the first winner left of the dealer button.
    const winners = scored
      .filter((entry) => entry.score === best)
      .map((entry) => entry.index)
      .sort((a, b) => ((a - table.dealer - 1 + seatCount) % seatCount) - ((b - table.dealer - 1 + seatCount) % seatCount));

    // Split in the table's smallest chip; odd chips go one by one to the winners left of the dealer.
    const unit = chipUnit(table.config);
    const units = Math.floor(distributable / unit + 1e-9);
    const leftover = distributable - units * unit;
    const each = Math.floor(units / winners.length);
    const odd = units - each * winners.length;
    winners.forEach((index, position) => {
      const chips = each + (position < odd ? 1 : 0);
      awards.push({
        seat: index,
        amount: roundMoney(chips * unit + (position === 0 ? leftover : 0)),
        label: describeScore(best),
      });
    });
  }

  collectBets(table);
  awardStack(table, awards);
  // Cards are face up now, so bet-sizing tells can be learned from public information.
  table.stats = recordShowdownTells(
    table.stats,
    hand.number,
    live.flatMap((index) => {
      const seat = table.seats[index];
      return seat ? [{ id: seat.id, isBot: seat.isBot, strong: scoreCategory(evaluateBest([...seat.hole, ...hand.board])) >= 2 }] : [];
    })
  );
  hand.rake = rakeTotal;
  hand.winners = awards;
  hand.showdown = true;
  hand.street = 'complete';
  hand.toAct = null;
  return table;
}

const needsAction = (seat: Seat, currentBet: number): boolean =>
  !seat.folded && !seat.allIn && (!seat.acted || seat.bet < currentBet);

function advance(table: TableState, from: number): TableState {
  const hand = table.hand;
  if (!hand) return table;
  const bigBlind = table.config.bigBlind;

  for (;;) {
    const live = table.seats.flatMap((seat, index) => (seat && !seat.folded ? [index] : []));
    if (live.length === 1) return finishUncontested(table, live[0]!);

    const pending = table.seats.some((seat) => seat && needsAction(seat, hand.currentBet));
    if (pending) {
      hand.toAct = nextSeat(table.seats, from, (seat) => needsAction(seat, hand.currentBet));
      return table;
    }

    if (hand.street === 'river') return showdown(table);

    collectBets(table);
    dealStreet(hand);
    hand.currentBet = 0;
    hand.minRaise = bigBlind;
    for (const seat of table.seats) if (seat) seat.acted = false;
    from = table.dealer;

    const canBet = table.seats.filter((seat) => seat && !seat.folded && !seat.allIn).length;
    if (canBet < 2) {
      collectBets(table);
      runOutBoard(hand);
      return showdown(table);
    }
  }
}

export function startHand(table: TableState, rakePercent: number): TableState {
  const next = cloneTable(table);
  const sb = table.config.smallBlind;
  const bb = table.config.bigBlind;
  next.seats = next.seats.map((seat) =>
    seat
      ? { ...seat, bet: 0, invested: 0, hole: [], folded: !canPlay(seat), allIn: false, acted: false }
      : null
  );

  const playable = next.seats.filter((seat): seat is Seat => !!seat && canPlay(seat)).length;
  if (playable < 2) return table;

  const dealer = nextSeat(next.seats, table.dealer, canPlay) ?? table.dealer;
  const headsUp = playable === 2;
  const smallBlindSeat = headsUp ? dealer : (nextSeat(next.seats, dealer, canPlay) ?? dealer);
  const bigBlindSeat = nextSeat(next.seats, smallBlindSeat, canPlay) ?? smallBlindSeat;

  const deck = createDeck();
  for (let round = 0; round < 2; round++) {
    let index = dealer;
    for (let step = 0; step < playable; step++) {
      const seatIndex = nextSeat(next.seats, index, canPlay);
      if (seatIndex === null) break;
      const seat = next.seats[seatIndex];
      if (seat) seat.hole.push(draw(deck));
      index = seatIndex;
    }
  }

  const sbSeat = next.seats[smallBlindSeat];
  const bbSeat = next.seats[bigBlindSeat];
  if (sbSeat) commit(sbSeat, sb);
  if (bbSeat) commit(bbSeat, bb);

  // The bet to match is always the full big blind, even when the big blind could only post part of it.
  const currentBet = Math.max(bb, ...next.seats.map((seat) => seat?.bet ?? 0));
  const firstActor = nextSeat(next.seats, bigBlindSeat, (seat) => !seat.folded && !seat.allIn);

  next.dealer = dealer;
  next.handCount = table.handCount + 1;
  next.hand = {
    number: next.handCount,
    street: 'preflop',
    board: [],
    deck,
    pot: 0,
    currentBet,
    minRaise: bb,
    toAct: firstActor,
    winners: [],
    rake: 0,
    rakePercent,
    showdown: false,
  };

  return advance(next, bigBlindSeat);
}

export function legalActions(table: TableState, index: number): LegalInfo | null {
  const hand = table.hand;
  const seat = table.seats[index];
  if (!hand || !seat || hand.toAct !== index) return null;
  const maxTo = seat.bet + seat.stack;
  const minTo = Math.min(hand.currentBet + hand.minRaise, maxTo);
  return {
    toCall: hand.currentBet - seat.bet,
    canCheck: hand.currentBet - seat.bet === 0,
    // A player who already acted and then faces only a short all-in raise may call or fold, not raise again.
    canRaise: maxTo > hand.currentBet && !(seat.acted && seat.bet < hand.currentBet),
    minTo,
    maxTo,
  };
}

export function applyAction(table: TableState, index: number, action: Action): TableState {
  const legal = legalActions(table, index);
  if (!legal) return table;

  const next = cloneTable(table);
  const hand = next.hand;
  const seat = next.seats[index];
  if (!hand || !seat) return table;
  const potBefore = potTotal(table);

  if (action.type === 'fold') {
    seat.folded = true;
    seat.acted = true;
  } else if (action.type === 'check') {
    if (!legal.canCheck) return table;
    seat.acted = true;
  } else if (action.type === 'call') {
    commit(seat, hand.currentBet - seat.bet);
    seat.acted = true;
  } else {
    const target = action.to;
    if (!legal.canRaise || target > legal.maxTo) return table;
    if (target < legal.minTo && target !== legal.maxTo) return table;
    if (target <= hand.currentBet && target !== legal.maxTo) return table;

    const increment = target - hand.currentBet;
    commit(seat, target - seat.bet);
    seat.acted = true;

    if (increment >= hand.minRaise) {
      hand.minRaise = increment;
      for (const other of next.seats) if (other && other !== seat) other.acted = false;
    }
    hand.currentBet = Math.max(hand.currentBet, seat.bet);
  }

  if (!seat.isBot) {
    const sizeFraction = action.type === 'raise' ? (Math.min(action.to, legal.maxTo) - (table.seats[index]?.bet ?? 0)) / Math.max(1, potBefore) : undefined;
    next.stats = recordAction(table, seat, legal.toCall, action, sizeFraction);
  }
  return advance(next, index);
}
